@extends( 'master' )

@section( 'title', 'Add New Post' )

@section( 'content' )
    <h1>Welcome</h1>
    <p>Hello from a BladeOne template, Posts - Add New</p>
@stop