@extends( 'master' )

@section( 'title', 'Home' )

@section( 'content' )
    <h1>Welcome</h1>
    <p>Hello from a BladeOne template, {{ $name }}</p>

    @foreach ( $colors as $color )
        <li>{{ $color }}</li>
    @endforeach

@stop