<?php

namespace App\Controllers;

use Core\View;
use App\Models\Post;

/**
 * Posts controller
 *
 * PHP version 7.0.22-2
 */
class Posts extends \Core\Controller
{
	/**
	 * Show the index page
	 *
	 * @return void
	 */
	public function indexAction() {
		$posts = Post::getAll();
		
		VIEW::renderTemplate( 'Posts.index', [
			'posts'     =>  $posts
		]);
	}
	
	/**
	 * Show the add new page
	 *
	 * @return void
	 */
	public function addNewAction() {
//		echo 'Hello from the addNew action in the Posts controller!';
		View::renderTemplate( 'Posts.add-new' );
	}
	
	/**
	 * Show the edit page
	 *
	 * @return void
	 */
	public function editAction() {
//		echo 'Hello from the edit action in teh Posts controller!';
//		echo '<p>Route parameters: <pre>' . htmlspecialchars( print_r( $this->route_params, true ) ) . '</pre></p>';
		View::renderTemplate( 'Posts.edit', [ 'params' => $this->route_params ] );
	}
}