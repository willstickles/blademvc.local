@extends( 'master' )

@section( 'title', 'Error' )

@section( 'content' )

    <h1>An error occurred</h1>
    <p>Sorry, an error has occurred.</p>

@stop