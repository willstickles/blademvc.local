@extends( 'master' )

@section( 'title', 'Signup' )

{{--@section( 'class_status', 'active' )--}}

@section( 'content' )

    <h1>Signup</h1>

    <p>Success! Thank you for signing up.</p>

    <p>Please check your email to activate your account.</p>

@stop