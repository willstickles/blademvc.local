@extends( 'master' )

@section( 'title', 'Sign up' )

@section( 'content' )

    <h1>Sign up</h1>

    <p>Success! Your account is now active. You can now <a href="/login">log in</a>.</p>

@stop