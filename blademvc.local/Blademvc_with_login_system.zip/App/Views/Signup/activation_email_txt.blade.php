Account activation

Thank you for signing up. Please click the following link to activate your account:

{{ $url }}