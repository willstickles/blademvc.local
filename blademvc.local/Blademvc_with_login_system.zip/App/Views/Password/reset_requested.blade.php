@extends( 'master' )

@section( 'title', 'Forgot password' )

@section( 'content' )

    <h1>Request password reset</h1>

    <p>Please check your email.</p>

@stop