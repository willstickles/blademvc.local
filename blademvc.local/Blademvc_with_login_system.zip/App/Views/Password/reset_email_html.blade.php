<h1>Password reset</h1>

<p>Please <a href="{{ $url }}">click here to reset your password</a>.</p>