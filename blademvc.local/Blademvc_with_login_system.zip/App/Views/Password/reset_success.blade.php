@extends( 'master' )

@section( 'title', 'Forgot password')

@section( 'content' )

    <h1>Password reset successfully</h1>

    <p>You can now <a href="/login">login</a>.</p>

@stop