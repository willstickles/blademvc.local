@extends( 'master' )

@section( 'title', 'Forgot password' )

@section( 'content' )

    <h1>Request password reset</h1>

    <p>Password reset link invalid or expired, please click <a href="/password/forgot">here</a> to request another one.</p>

@stop