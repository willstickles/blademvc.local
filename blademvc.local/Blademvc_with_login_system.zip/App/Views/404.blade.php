@extends( 'master' )

@section( 'title', 'Page not found' )

@section( 'content' )

    <h1>Page not found</h1>
    <p>Sorry, that page doesn't exist.</p>

@stop